from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from functools import partial
from urllib.parse import urlencode, parse_qsl, quote_plus, urlparse, unquote
from concurrent.futures import ThreadPoolExecutor
from http.client import HTTPConnection
from xbmcvfs import translatePath, File
from xbmc import executebuiltin, getInfoLabel
from json import loads, dumps
from pickle import load, dump
from requests import Session
from xbmcaddon import Addon
from htmlement import fromstring
from xbmcgui import ListItem, Dialog, DialogProgress, WindowXMLDialog, INPUT_ALPHANUM, NOTIFICATION_INFO
from time import time, localtime, strftime, strptime, struct_time, mktime
import re, sys, os
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
USERDATA = os.path.join(translatePath('special://home/'), 'userdata')
ADVANCED = os.path.join(USERDATA, 'advancedsettings.xml')
RAM = int(getInfoLabel('System.Memory(total)')[:-2])
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
ting = RESOURCES + 'ting.mp3'
UA = 'Mozilla/5.0 (Linux; Android 16; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/605.1.15 EdgA/140.0.0.0'
ufn = 'https://thuvienhd.top'
bm = 'http://lite.baomoi.com/'
userfs = 'FshareiOSApp-saCP7ssw2u7w'
keyfs = '2C4ErbRVwcxmUtPTwR5uZq6Svz54JbHc'
tmdbAPI = 'https://api.themoviedb.org/3'
apimdb = 'b030404650f279792a8d3287232358e3'
apiKey = f'{apimdb}&language=vi-VN'
append = 'alternative_titles,credits,external_ids,keywords,videos,recommendations'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
thaythe = {'|':'$','@':'', '*': ''}
def addDir(title=None, img=None, plot=None, size=None, add_key=None, del_key=None, mode=None, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = ListItem(label=f'{title}')
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{plot}')
    setContent(HANDLE, 'videos')
    if size is not None:
        list_item.setInfo(type='Video', infoLabels={'size': size})
    if add_key is not None:
        list_item.addContextMenuItems([('Thêm vào Favourite', f'RunPlugin({addon_url}?mode=add_key&key={add_key})')])
    if del_key is not None:
        list_item.addContextMenuItems([('Xóa khỏi Favourite', f'RunPlugin({addon_url}?mode=del_key&key={del_key})')])
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    with Session() as s:
        s.headers.update({'user-agent': UA,'referer': ref.encode('utf-8')})
        try:
            r = s.get(url, timeout=20)
        except:
            r = s.get(url, timeout=20, verify=False)
    r.encoding = 'utf-8'
    return r
def domhtml(root, xpath, attribute=None, default=None):
    element = root.find(xpath)
    return default if element is None else element.get(attribute, '\n'.join(element.itertext()).strip())
def urlfix(url):
    cleaned_location = '%20'.join(url.strip().split())
    return re.sub(r':(\/+)', r'://', cleaned_location)
def fu(url):
    parsed_url = urlparse(url)
    conn = HTTPConnection(parsed_url.netloc)
    conn.request('HEAD', parsed_url.path)
    response = conn.getresponse().getheader('Location')
    if response is not None:
        return urlfix(response)
    else:
        with Session() as s:
            try:
                r = s.get(url, allow_redirects=False)
            except:
                r = s.get(url, verify=False, allow_redirects=False)
        try:
            return urlfix(r.headers['Location'])
        except:
            return urlfix(r.url)
def get_tkfs1(search_query):
    r1 = getlink(f'{ufn}/?feed=fsharejson&search={search_query}', ufn)
    r2 = getlink(f'{ufn}/?feed=fsharejson&search=', ufn)
    return ((t['image'], t['title'].replace('&&','-'), t['id']) for t in r1.json() if r1.content != r2.content)
def get_tkfs2(search_query):
    urlx = f'https://timfshare.com/api/v1/string-query-search?query={search_query}'
    with Session() as s:
        s.headers.update({'user-agent': UA, 'referer': 'https://timfshare.com/'})
        try:
            r = s.post(urlx, timeout=20)
        except:
            r = s.post(urlx, timeout=20, verify=False)
    data_sorted = sorted(response.json().get('data', []), key=lambda k: k['created'], reverse=True)
    return ((item['name'], item['url'], item['size']) for item in data_sorted)
def getrow(row):
    return row['v'] if (row is not None) and (row['v'] is not None) else ''
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def has_file_path(filename):
    return os.path.exists(get_file_path(filename))
def remove_file(filename):
    if has_file_path(filename):
        os.remove(get_file_path(filename))
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def convert_to_kb(size_str):
    size_str = size_str.strip().lower()
    if "gb" in size_str:
        size_in_gb = float(size_str.replace("gb", "").strip())
        return int(size_in_gb * 1024 * 1024 * 1024)
    elif "mb" in size_str:
        size_in_mb = float(size_str.replace("mb", "").strip())
        return int(size_in_mb * 1024 * 1024)
    elif "kb" in size_str:
        size_in_kb = float(size_str.replace("kb", "").strip())
        return int(size_in_kb * 1024)
    else:
        return None
def replace_all(dict, str):
    pattern = re.compile('|'.join(re.escape(key) for key in dict.keys()))
    return pattern.sub(lambda match: dict[match.group()], str)
def TextBox(title, msg):
    class TextBoxes(WindowXMLDialog):
        def onInit(self):
            self.title      = 101
            self.msg        = 102
            self.scrollbar  = 103
            self.okbutton   = 201
            self.showdialog()
        def showdialog(self):
            self.getControl(self.title).setLabel(title)
            self.getControl(self.msg).setText(msg)
            self.setFocusId(self.scrollbar)
        def onClick(self, controlId):
            if (controlId == self.okbutton):
                self.close()
        def onAction(self, action):
            if   action == ACTION_PREVIOUS_MENU: self.close()
            elif action == ACTION_NAV_BACK: self.close()
    tb = TextBoxes('Textbox.xml', PATH, 'DefaultSkin', title=title, msg=msg)
    tb.doModal()
    del tb
def settingskodi():
    executebuiltin('Addon.OpenSettings(plugin.video.thuvienhd)')
def writeAdvanced():
    buffer = int(RAM/7.68)
    chunk = buffer*6554
    if os.path.exists(ADVANCED):
        os.remove(ADVANCED)
    content = f"""<advancedsettings version="1.0">
       <network>
           <curlclienttimeout>5</curlclienttimeout>
           <curllowspeedtime>5</curllowspeedtime>
           <curlretries>2</curlretries>
           <disableipv6>true</disableipv6>
           <disablehttp2>true</disablehttp2>
           <nfstimeout>5</nfstimeout>
           <nfsretries>0</nfsretries>
           <curlkeepaliveinterval>5</curlkeepaliveinterval>
       </network>
       <filecache>
           <memorysize>{buffer}</memorysize>
           <chunksize>{chunk}</chunksize>
       </filecache>
       <addons>
           <unknownsources>true</unknownsources>
           <updatemode>1</updatemode>
       </addons>
       <services>
           <webserver>true</webserver>
           <webserverauthentication>false</webserverauthentication>
           <esallinterfaces>true</esallinterfaces>
       </services>
       <locale>
           <language>resource.language.vi_vn</language>
           <country>Vietnam</country>
           <subtitlelanguage>Vietnamese</subtitlelanguage>
       </locale>
       <subtitles>
           <languages>Vietnamese</languages>
       </subtitles>
       <disc>
           <playback>2</playback>
       </disc>
       <eventlog>
           <enabled>false</enabled>
       </eventlog>
    </advancedsettings>
    """
    with File(ADVANCED, 'w') as f:
        f.write(content)
    Dialog().notification(addon_name, 'Khởi động lại kodi để nhận cấu hình mới', NOTIFICATION_INFO, 5000)
    tingting()
def userpassfs():
    username = Addon().getSetting('username')
    password = Addon().getSetting('password')
    if username and password:
        try:
            try:
                f = read_file('token_session.pkl')
                token = f['token']
                session_id = f['session_id']
            except:
                payload = {'user_email':username, 'password':password, 'app_key':keyfs}
                with Session() as q:
                    q.headers.update({'user-agent':userfs, 'content-type': 'application/json; charset=utf-8'})
                    try:
                        response = q.post('https://api.fshare.vn/api/user/login', timeout=20, data=dumps(payload))
                    except:
                        response = q.post('https://api.fshare.vn/api/user/login', timeout=20, data=dumps(payload), verify=False)
                token = response.json()['token']
                session_id = response.json()['session_id']
            with Session() as s:
                s.headers.update({'user-agent':userfs, 'cookie' : f'session_id={session_id}'})
                try:
                    r = s.get('https://api.fshare.vn/api/user/get', timeout=20)
                except:
                    r = s.get('https://api.fshare.vn/api/user/get', timeout=20, verify=False)
            if r.status_code == 200:
                datawrite = {'token': token, 'session_id': session_id}
                write_file('token_session.pkl', datawrite)
                return (token, session_id)
            else:
                payloadtoken = {'token':token, 'app_key':keyfs}
                try:
                    r = s.post('https://api.fshare.vn/api/user/refreshToken', timeout=20, data=dumps(payloadtoken))
                except:
                    r = s.post('https://api.fshare.vn/api/user/refreshToken', timeout=20, data=dumps(payloadtoken), verify=False)
                token = r.json()['token']
                session_id = r.json()['session_id']
                datawrite = {'token': token, 'session_id': session_id}
                write_file('token_session.pkl', datawrite)
                return (token, session_id)
        except:
            executebuiltin('Notification("%s", "%s", "%d", "%s")' % (addon_name, 'Đăng nhập thất bại', 5000, ICON))
            sys.exit()
    else:
        executebuiltin('Notification("%s", "%s", "%d", "%s")' % (addon_name, 'Vui lòng nhập tài khoản Fshare trong cài đặt của ThuVienHD', 5000, ICON))
        sys.exit()
def check_myip():
    r = getlink('https://redirector.googlevideo.com/report_mapping?di=no', 'https://www.google.com.vn/').text
    Dialog().ok(addon_name, r)
    tingting()
def tingting():
    play_item = ListItem(offscreen=True, path=ting)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def dubaothoitiet():
    addDir('Vị trí của bạn', ICON, 'Vị trí của bạn', None, None, None, 'thoitietmylocal', is_folder=False)
    resp = getlink(bm, bm).text
    idbm = re.search(r'buildId":"(.*?)"', resp)[1]
    u = f'https://baomoi.com/_next/data/{idbm}/utilities/weather.json'
    r = getlink(u,u).json()['pageProps']['resp']['data']['content']['boards']
    for k in r:
        name = k['displayName']
        shortName = k['shortName']
        addDir(name, ICON, name, None, None, None, 'weather', shortName=shortName, idbm=idbm, ten=name, is_folder=False)
    endOfDirectory(HANDLE)
def weather(shortName, idbm, ten):
    TITLE = f'THỜI TIẾT {ten.upper()}'
    u = f'https://baomoi.com/_next/data/{idbm}/utilities/weather/{shortName}.json?province={shortName}'
    r = getlink(u,u).json()['pageProps']['resp']['data']['content']['activeBoard']['entries']
    output = []
    for t in r:
        ngay = '/'.join(t['date'].split('/')[:2])
        status = t['status']
        temperatureMin24Hour = t['temperatureMin24Hour']
        temperatureMax24Hour = t['temperatureMax24Hour']
        current_block1 = (
            f"{ngay} {temperatureMin24Hour}-{temperatureMax24Hour}°C {status}\n{'-'*40}\n"
        )
        output.append(current_block1)
    for k in r:
        ngay = '/'.join(k['date'].split('/')[:2])
        gio = k['hours']
        for m in gio:
            hour = m['hours']
            nhietdo = m['temperature']
            doam = m['humidity']
            gio = m['wind']
            khanangmua = m['pop']
            statushientai = m['status']
            current_block2 = (
                f"[COLOR yellow]{hour}:00 {ngay}[/COLOR] {nhietdo}°C {statushientai}\nĐộ ẩm {doam}%\nGió {gio}km/h\nKhả năng mưa {khanangmua}%\n{'-'*40}\n"
            )
            output.append(current_block2)
    result = ''.join(output)
    TextBox(TITLE, result)
    tingting()
def thoitietmylocal():
    wind_dir_vi = {
        "N": "Bắc", "NNE": "Bắc Đông Bắc", "NE": "Đông Bắc", "ENE": "Đông Đông Bắc",
        "E": "Đông", "ESE": "Đông Đông Nam", "SE": "Đông Nam", "SSE": "Nam Đông Nam",
        "S": "Nam", "SSW": "Nam Tây Nam", "SW": "Tây Nam", "WSW": "Tây Tây Nam",
        "W": "Tây", "WNW": "Tây Tây Bắc", "NW": "Tây Bắc", "NNW": "Bắc Tây Bắc"
    }
    output = []
    ipap = 'https://check-host.net/ip/widget.js'
    city = re.search(r'\((.*?),', getlink(ipap, 'https://check-host.net/').text)[1]
    wttr_url = f'https://vi.wttr.in/{city}?format=j1'
    body = getlink(wttr_url, wttr_url).json()
    TITLE = f'THỜI TIẾT [COLOR yellow]{city.upper()}[/COLOR]'
    now = localtime()
    days = body['weather']
    for day in days:
        date_struct = strptime(day['date'], "%Y-%m-%d")
        day_num = date_struct.tm_mday
        month_num = date_struct.tm_mon
        date_fmt = f"{day_num}/{month_num}"
        for hour in day['hourly']:
            time_int = int(hour['time'])
            hour_num = time_int // 100
            minute_num = time_int % 100
            hourly_struct = struct_time((
                date_struct.tm_year,
                date_struct.tm_mon,
                date_struct.tm_mday,
                hour_num,
                minute_num,
                0,
                -1, -1, -1
            ))
            hourly_ts = mktime(hourly_struct)
            now_ts = mktime(now)
            if hourly_ts >= now_ts:
                gio = f"{hour_num:02d}:{minute_num:02d}"
                desc = hour['lang_vi'][0]['value']
                tempC = hour['tempC']
                humidity = hour['humidity']
                wind_speed = hour['windspeedKmph']
                wind_dir = wind_dir_vi.get(hour['winddir16Point'], hour['winddir16Point'])
                visibility = hour['visibility']
                block = (
                    f"[COLOR yellow]{gio} {date_fmt}[/COLOR] {desc}\n"
                    f"Nhiệt độ {tempC}°C\n"
                    f"Độ ẩm {humidity}%\n"
                    f"Gió {wind_dir} {wind_speed} km/h\n"
                    f"Tầm nhìn xa {visibility} km\n"
                    f"{'-'*40}\n"
                )
                output.append(block)
    result = ''.join(output)
    TextBox(TITLE, result)
    tingting()
def down(url):
    with Session() as s:
        s.headers.update({'user-agent': UA})
        try:
            r = s.get(url, stream=True)
        except:
            r = s.get(url, stream=True, verify=False)
    return r
def myip():
    r = getlink('https://speed.cloudflare.com/meta', 'https://speed.cloudflare.com/meta').json()
    return (r['clientIp'], r['asOrganization'], r['colo'], r['country'], r['city'])
def speedtestcf():
    dp = DialogProgress()
    dp.create(addon_name, 'Đang đo tốc độ mạng')
    dp.update(0, 'Đang kết nối tới máy chủ')
    total, file_size = 524288000, 500
    with ThreadPoolExecutor(2) as ex:
        f1 = ex.submit(down, f'https://speed.cloudflare.com/__down?bytes={total}')
        f2 = ex.submit(myip)
        r1 = f1.result()
        r2 = f2.result()
    downloaded = 0
    start_time = time()
    for chunk in r1.iter_content(chunk_size=1024):
        downloaded += len(chunk)
        done = int(1e2 * downloaded/total)
        elapsed_time = time() - start_time
        if elapsed_time > 0:
            kbps_speed = (downloaded/(time() - start_time))/1048576
        else:
            kbps_speed = 0
        td = f'{kbps_speed:.02f} MB/s'
        speed = f'Download [COLOR yellow]{td}[/COLOR] - Server location [COLOR yellow]{r2[2]}[/COLOR]\nIP address [COLOR yellow]{r2[0]}[/COLOR]\nNetwork [COLOR yellow]{r2[1]}[/COLOR]\nGeolocation [COLOR yellow]{r2[4]} - {r2[3]}[/COLOR]'
        if dp.iscanceled():
            dp.close()
            sys.exit()
        dp.update(done, speed)
    download_time = time() - start_time
    speed_kbps = int(file_size/download_time)
    if speed_kbps <= 5:
        quality = 'SD 480p'
    elif speed_kbps <= 10:
        quality = 'HD 720p'
    elif speed_kbps <= 20:
        quality = 'FHD 1080p'
    elif speed_kbps <= 30:
        quality = '2K 1440p'
    elif speed_kbps <= 50:
        quality = '4K 2160p'
    else:
        quality = '8K 4320p'
    Dialog().ok(addon_name, f'Băng thông hiện tại: [COLOR yellow]{speed_kbps*8}[/COLOR] Mbps\nChất lượng video đề xuất: [COLOR yellow]{quality}[/COLOR]')
    dp.close()
    tingting()
def infoaccountfs():
    token, session_id = userpassfs()
    headerfsvn = {'user-agent':userfs, 'cookie' : f'session_id={session_id}'}
    with Session() as s:
        s.headers.update(headerfsvn)
        try:
            r = s.get('https://api.fshare.vn/api/user/get', timeout=20)
        except:
            r = s.get('https://api.fshare.vn/api/user/get', timeout=20, verify=False)
    idacc = r.json()['id']
    email = r.json()['email']
    account_type = r.json()['account_type']
    expire_vip = int(r.json()['expire_vip'])
    time_struct = localtime(expire_vip)
    formatted = strftime('%d/%m/%Y', time_struct)
    Dialog().ok(addon_name, f'ID: {idacc}\nEmail: {email}\nAcc Type: {account_type}\nVIP Expiry: {formatted}')
    tingting()
def favouritefs():
    token, session_id = userpassfs()
    headerfsvn = {'user-agent':userfs, 'cookie' : f'session_id={session_id}'}
    with Session() as s:
        s.headers.update(headerfsvn)
        try:
            r = s.get('https://api.fshare.vn/api/fileops/listfavorite', timeout=20)
        except:
            r = s.get('https://api.fshare.vn/api/fileops/listfavorite', timeout=20, verify=False)
    for k in r.json():
        name = k['name']
        linkcode = k['linkcode']
        typef = int(k['type'])
        size = k['size']
        if typef == 1:
            linkfs = f'https://www.fshare.vn/file/{linkcode}'
            addDir(name, ICON, name, k['size'], None, linkfs, 'play_fs', link = linkfs, tenphim = name, key = linkfs, is_folder=False)
        else:
            linkfs = f'https://www.fshare.vn/folder/{linkcode}'
            addDir(name, ICON, name, None, None, linkfs, 'index_fs', link = linkfs, p=1, key = linkfs)
    endOfDirectory(HANDLE)
def add_key(key):
    idfd = re.search(r'(file|folder)/([A-Z0-9]+)', key)[2]
    token, session_id = userpassfs()
    headerfsvn = {'user-agent':userfs, 'cookie' : f'session_id={session_id}'}
    payload = {'token': token, 'items': [idfd], 'status': 1}
    with Session() as s:
        s.headers.update(headerfsvn)
        try:
            s.post('https://api.fshare.vn/api/fileops/ChangeFavorite', timeout=20, data=dumps(payload))
        except:
            s.post('https://api.fshare.vn/api/fileops/ChangeFavorite', timeout=20, data=dumps(payload), verify=False)
    Dialog().notification(addon_name, 'Đã thêm vào Favourite', NOTIFICATION_INFO, 5000)
def del_key(key):
    idfd = re.search(r'(file|folder)/([A-Z0-9]+)', key)[2]
    token, session_id = userpassfs()
    headerfsvn = {'user-agent':userfs, 'cookie' : f'session_id={session_id}'}
    payload = {'token': token, 'items': [idfd], 'status': 0}
    with Session() as s:
        s.headers.update(headerfsvn)
        try:
            s.post('https://api.fshare.vn/api/fileops/ChangeFavorite', timeout=20, data=dumps(payload))
        except:
            s.post('https://api.fshare.vn/api/fileops/ChangeFavorite', timeout=20, data=dumps(payload), verify=False)
    executebuiltin('Container.Refresh()')
def listvmf_gcs(url):
    resp = getlink(url, url)
    ri = resp.iter_lines(decode_unicode=True)
    tach = (ll.rstrip() for ll in ri if ll.strip())
    for link in tach:
        create_listitem_from_link(link)
    endOfDirectory(HANDLE)
def set_item_callbacks(link, name, info, anh, sub):
    if 'fshare.vn/folder' in link:
        return addDir(name, anh, info, None, link, None, 'index_fs', link = link, p=1, key = link)
    elif 'fshare.vn/file' in link:
        return addDir(name, anh, info, None, link, None, 'play_fs', link = link, tenphim = name, key = link, is_folder=False)
    elif 'docs.google.com' in link:
        return addDir(name, anh, info, None, None, None, 'listgg_gcs', link = link)
    elif 'VMF' in link:
        return addDir(name, anh, info, None, None, None, 'listvmf_gcs', link = link.replace('VMF-', ''))
    elif 'timvmf' in link:
        return addDir(name, anh, info, None, None, None, 'timvmf', link = link.replace('timvmf-', ''))
    else:
        return addDir(name, anh, info, None, None, None, 'play_vnm', link = link, tenphim = name, sub=sub, is_folder=False)
def create_listitem_from_link(link):
    tachhat = link.split('$')
    ltach = len(tachhat)
    if ltach > 1:
        kenh = tachhat[1]
        tenm = tachhat[0]
        imgfs = tachhat[3] if ltach > 3 else ICON
        sub = tachhat[2] if ltach > 2 else None
        if ltach > 4:
            info = tachhat[4]
        else:
            info = tenm
        return set_item_callbacks(kenh, tenm, info, imgfs, sub)
def listgg_gcs(x):
    if 'gid' in x:
        match = next(re.finditer(r'/d/(.*?)/.*?gid=(\d+)', x), None)
        sid, gid = match[1], match[2]
    else:
        match = next(re.finditer(r'/d/(.*?)/', x), None)
        sid = match[1]
        gid = '0'
    url = f'https://docs.google.com/spreadsheets/d/{sid}/gviz/tq?gid={gid}&headers=1'
    resp = getlink(url, url)
    noi = re.search(r'\{.*\}', resp.text)[0]
    m = loads(noi)
    cols = m['table']['cols']
    rows = m['table']['rows']
    kenh = cols[1]['label']
    if 'http' in kenh:
        lcols = len(cols)
        tenm = cols[0]['label']
        imgfs = cols[2]['label'] if lcols > 2 else ICON
        if lcols > 3:
            info = f"{cols[3]['label']}"
        else:
            info = f'{tenm}\nNguồn: {u}'
        set_item_callbacks(kenh, tenm, info, imgfs, None)
    for cow in cols:
        p = cow['label']
        if '|http' in p:
            create_listitem_from_link(replace_all(thaythe, p))
    for row in rows:
        k = getrow(row['c'][0])
        if '|http' in k:
            create_listitem_from_link(replace_all(thaythe, k))
        elif 'http' in getrow(row['c'][1]):
            lrow = len(row['c'])
            kenh = getrow(row['c'][1])
            imgfs = getrow(row['c'][2]) if lrow > 2 else ICON
            if lrow > 3:
                info = getrow(row['c'][3])
            else:
                info = f'{k}\nNguồn: {u}'
            set_item_callbacks(kenh, k, info, imgfs, None)
    endOfDirectory(HANDLE)
def index_gcs():
    u = Addon().getSetting('TextURL')
    if u:
        x = fu(u)
        if 'docs.google.com' in x:
            listgg_gcs(x)
        else:
            listvmf_gcs(u)
    else:
        main()
def main():
    addDir('Tìm phim', searchimg, 'Tìm phim', None, None, None, 'timkiem')
    T = {
        'The Movie Database': 'fsmdb_full',
        'Phim lẻ': 'tvhd_phimle',
        'Phim bộ': 'tvhd_phimbo',
        'Nhạc': 'tvhd_nhac'}
    dulieu = {
        'Phim lẻ mới':f'{ufn}/genre/phim-le',
        'Phim bộ mới':f'{ufn}/genre/series',
        'Thuyết minh':f'{ufn}/genre/thuyet-minh-tieng-viet',
        'Lồng tiếng':f'{ufn}/genre/long-tieng-tieng-viet',
        'H265':f'{ufn}/genre/h265',
        '3D':f'{ufn}/genre/3d',
        '4K':f'{ufn}/genre/4k',
        'ATV':f'{ufn}/genre/atv',
        'Bluray':f'{ufn}/genre/bluray-nguyen-goc',
        'TVB':f'{ufn}/genre/tvb',
        'Bộ sưu tập':f'{ufn}/genre/collection',
        'TV Shows':f'{ufn}/genre/tv-show',
        'TV':f'{ufn}/genre/tv',
        'Phim truyền hình':f'{ufn}/genre/tv-movie',
        'Phim hoạt hình':f'{ufn}/genre/animation',
        'Phim 18':f'{ufn}/genre/18'
        }
    for b in T:
        addDir(b, ICON, b, None, None, None, T[b])
    for h in dulieu:
        addDir(h, ICON, h, None, None, None, 'thuvienhd_page', url = f'{dulieu[h]}/page/', p=1)
    addDir('Góc chia sẻ', ICON, 'Góc chia sẻ', None, None, None, 'index_gcs')
    addDir('Tiện ích', ICON, 'Tiện ích', None, None, None, 'caidat')
    endOfDirectory(HANDLE)
def caidat():
    addDir('Cài đặt', ICON, 'Cài đặt', None, None, None, 'settingskodi', is_folder=False)
    addDir('Thông tin tài khoản', ICON, 'Thông tin tài khoản', None, None, None, 'infoaccountfs', is_folder=False)
    addDir('Fshare Favourite', ICON, 'Fshare Favourite', None, None, None, 'favouritefs')
    addDir('Tăng tốc kodi', ICON, 'Tăng tốc kodi', None, None, None, 'tangtockodi', is_folder=False)
    addDir('Địa chỉ IP', ICON, 'Địa chỉ IP', None, None, None, 'check_myip', is_folder=False)
    addDir('Dự báo thời tiết', ICON, 'Dự báo thời tiết', None, None, None, 'dubaothoitiet')
    addDir('Đo tốc độ mạng', ICON, 'Đo tốc độ mạng', None, None, None, 'speedtestcf', is_folder=False)
    endOfDirectory(HANDLE)
def timkiem(query):
    search_query = quote_plus(query)
    with ThreadPoolExecutor(2) as ex:
        f1 = ex.submit(get_tkfs1, search_query)
        f2 = ex.submit(get_tkfs2, search_query)
    try:
        for k1 in f1.result():
            img = k1[0]
            name = k1[1]
            idk = k1[2]
            addDir(name, img, name, None, None, None, 'thuvienhd_link', idk = idk, info = name, ground = img)
    except:
        pass
    try:
        for k2 in f2.result():
            name = k2[0]
            url = k2[1]
            size = k2[2]
            addDir(name, ICON, name, size, url, None, 'play_fs', link = url, tenphim = name, key = url, is_folder=False)
    except:
        pass
    endOfDirectory(HANDLE)
def timkiem_fsmdb(query):
    search_query = quote_plus(query)
    url = f'{tmdbAPI}/search/multi?api_key={apiKey}&query={search_query}'
    next_page = 1
    fsmdb(url, next_page)
    endOfDirectory(HANDLE)
def find():
    addDir('Tìm phim', searchimg, 'Tìm phim', None, None, None, 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, ICON, m, None, None, None, 'tim_fs', key = m)
    endOfDirectory(HANDLE)
def find_fsmdb():
    addDir('Tìm phim', searchimg, 'Tìm phim', None, None, None, 'search_fsmdb')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, ICON, m, None, None, None, 'tim_fsmdb', key = m)
    endOfDirectory(HANDLE)
def fsmdb(url, next_page):
    u = f'{url}&page={next_page}'
    r = getlink(u, u)
    rj = r.json()
    for k in rj['results']:
        if 'known_for' in k:
            s = k['known_for'][0]
            try:
                ten = s['name']
            except:
                ten = s['title']
        else:
            try:
                ten = k['name']
            except:
                ten = k['title']
        addDir(ten, f"https://image.tmdb.org/t/p/w500{k['poster_path']}", k['overview'], None, None, None, 'id_fsmdb', u=u, id = k['id'])
    if next_page < rj['total_pages']:
        trang = f'{next_page + 1}'
        addDir(f'Trang {trang}', nextimg, f'Trang {trang}', None, None, None, 'ds_fsmdb', url = u, p=trang)
def play_fs(link):
    token, session_id = userpassfs()
    payload = {'zipflag':0, 'url': link, 'password':'', 'token': token}
    headerfsvn = {'user-agent':userfs, 'cookie' : f'session_id={session_id}', 'content-type': 'application/json; charset=utf-8'}
    with Session() as s:
        s.headers.update(headerfsvn)
        try:
            uf = s.post('https://api.fshare.vn/api/session/download', timeout=20,data=dumps(payload))
        except:
            uf = s.post('https://api.fshare.vn/api/session/download', timeout=20,data=dumps(payload), verify=False)
    if 'location' in uf.text:
        linkplay = re.sub(r'\s+', '%20', uf.json()['location'].strip(), flags=re.UNICODE)
        play_item = ListItem(offscreen=True, path=linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
def play_vnm(url, sub=None):
    play_item = ListItem(offscreen=True)
    if sub is not None:
        play_item.setSubtitles([sub])
    uplay = url[6:]
    if 'm3u8' in uplay:
        if any((re.search(r':(?!/)', uplay), ('?' in uplay))):
            linkplay = re.sub(r'\s+', '%20', url.strip(), flags=re.UNICODE)
            play_item.setPath(f'{linkplay}|verifypeer=false&User-Agent={unquote(UA)}')
        elif '|' in uplay:
            d = url.split('|')
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.stream_headers', d[1])
            play_item.setProperty('inputstream.adaptive.manifest_headers', d[1])
            play_item.setPath(d[0])
        else:
            hdr = f'User-Agent={UA}'
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
            play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
            play_item.setPath(url)
    else:
        linkplay = re.sub(r'\s+', '%20', url.strip(), flags=re.UNICODE)
        play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def tvhd_phimle():
    dulieu = {
        'Mới nhất':f'{ufn}/genre/phim-le',
        '3D': f'{ufn}/genre/3d',
        '4K': f'{ufn}/genre/4k',
        'Âm Nhạc': f'{ufn}/genre/am-nhac',
        'Ấn Độ': f'{ufn}/genre/india',
        'Bản quyền': f'{ufn}/genre/copyright',
        'Bí Ẩn': f'{ufn}/genre/bi-an',
        'Cao Bồi': f'{ufn}/genre/western',
        'Chiến Tranh': f'{ufn}/genre/war',
        'Chính Kịch': f'{ufn}/genre/chinh-kich',
        'Cổ Trang': f'{ufn}/genre/co-trang-phim',
        'Gây cấn': f'{ufn}/genre/gay-can',
        'Gia Đình': f'{ufn}/genre/gia-dinh',
        'Hài': f'{ufn}/genre/comedy',
        'Hàn Quốc': f'{ufn}/genre/korean',
        'Hành Động': f'{ufn}/genre/action',
        'Hình Sự': f'{ufn}/genre/crime',
        'Hồi hộp': f'{ufn}/genre/hoi-hop',
        'Hongkong': f'{ufn}/genre/hongkong',
        'Huyền Bí': f'{ufn}/genre/mystery',
        'Kinh Dị': f'{ufn}/genre/horror',
        'Lãng Mạn': f'{ufn}/genre/romance',
        'Lịch Sử': f'{ufn}/genre/history',
        'Nhạc Kịch': f'{ufn}/genre/nhac-kich',
        'Phiêu Lưu': f'{ufn}/genre/adventure',
        'Rùng Rợn': f'{ufn}/genre/thriller',
        'Tâm Lý': f'{ufn}/genre/drama',
        'Thần Thoại': f'{ufn}/genre/fantasy',
        'Thể Thao': f'{ufn}/genre/the-thao',
        'Thiếu Nhi': f'{ufn}/genre/family',
        'Tiểu Sử': f'{ufn}/genre/tieu-su',
        'Tình Cảm': f'{ufn}/genre/tinh-cam',
        'Tội Phạm': f'{ufn}/genre/toi-pham',
        'Trinh Thám': f'{ufn}/genre/trinh-tham',
        'Trung Quốc': f'{ufn}/genre/trung-quoc-series',
        'Viễn Tưởng': f'{ufn}/genre/sci-fi',
        'Việt Nam': f'{ufn}/genre/vietnamese',
        'Võ Thuật': f'{ufn}/genre/vo-thuat-phim-2',
        'Giáng Sinh': f'{ufn}/genre/giang-sinh',
        'Phim Hoạt Hình': f'{ufn}/genre/animation',
        'Phim Tài Liệu': f'{ufn}/genre/documentary',
        'Phim': f'{ufn}/genre/phim'
    }
    for k in dulieu:
        addDir(k, ICON, k, None, None, None, 'thuvienhd_page', url = f'{dulieu[k]}/page/', p=1)
    endOfDirectory(HANDLE)
def tvhd_phimbo():
    dulieu = {
        'Mới nhất':f'{ufn}/genre/series',
        'Phim Bộ Nigeria': f'{ufn}/genre/phi-bo-nigeria',
        'Phim Bộ Ả Rập': f'{ufn}/genre/phim-bo-a-rap',
        'Phim Bộ Ai Cập': f'{ufn}/genre/phim-bo-ai-cap',
        'Phim Bộ Ái Nhĩ Lan (Ireland)': f'{ufn}/genre/phim-bo-ai-nhi-lan-ireland',
        'Phim Bộ Ấn Độ': f'{ufn}/genre/phim-bo-an-do',
        'Phim bộ Anh': f'{ufn}/genre/phim-bo-anh',
        'Phim Bộ Áo': f'{ufn}/genre/phim-bo-ao',
        'Phim Bộ Argentina': f'{ufn}/genre/phim-bo-argentina',
        'Phim Bộ Australia': f'{ufn}/genre/phim-bo-australia',
        'Phim Bộ Ba Lan': f'{ufn}/genre/phim-bo-ba-lan',
        'Phim Bộ Bỉ': f'{ufn}/genre/phim-bo-bi',
        'Phim Bộ Bồ Đào Nha': f'{ufn}/genre/phim-bo-bo-dao-nha',
        'Phim Bộ Brazil': f'{ufn}/genre/phim-bo-brazil',
        'Phim Bộ Canada': f'{ufn}/genre/phim-bo-canada',
        'Phim Bộ Chile': f'{ufn}/genre/phim-bo-chile',
        'Phim Bộ Colombia': f'{ufn}/genre/phim-bo-colombia',
        'Phim Bộ Đài Loan': f'{ufn}/genre/phim-bo-dai-loan',
        'Phim Bộ Đan Mạch': f'{ufn}/genre/phim-bo-dan-mach',
        'Phim Bộ Đức': f'{ufn}/genre/phim-bo-duc',
        'Phim Bộ Hà Lan': f'{ufn}/genre/phim-bo-ha-lan',
        'Phim Bộ Hàn': f'{ufn}/genre/korean-series',
        'Phim Bộ Hongkong': f'{ufn}/genre/hongkong-series',
        'Phim Bộ Iceland': f'{ufn}/genre/phim-bo-iceland',
        'Phim Bộ Ireland': f'{ufn}/genre/phim-bo-ireland',
        'Phim Bộ Israel': f'{ufn}/genre/phim-bo-israel',
        'Phim Bộ Jordan': f'{ufn}/genre/phim-bo-jordan',
        'Phim Bộ Mexico': f'{ufn}/genre/phim-bo-mexico',
        'Phim Bộ Mỹ': f'{ufn}/genre/us-tv-series',
        'Phim Bộ Na Uy': f'{ufn}/genre/phim-bo-na-uy',
        'Phim Bộ Nam Phi': f'{ufn}/genre/phim-bo-nam-phi',
        'Phim Bộ New Zealand': f'{ufn}/genre/phim-bo-new-zealand',
        'Phim Bộ Nga': f'{ufn}/genre/phim-bo-nga',
        'Phim Bộ Nhật Bản': f'{ufn}/genre/phim-bo-nhat-ban',
        'Phim Bộ Phần Lan': f'{ufn}/genre/phim-bo-phan-lan',
        'Phim Bộ Pháp': f'{ufn}/genre/phim-bo-phap',
        'Phim Bộ Philippines': f'{ufn}/genre/phim-bo-philippines',
        'Phim Bộ Romania': f'{ufn}/genre/phim-bo-romania',
        'Phim Bộ Singapo': f'{ufn}/genre/phim-bo-singapo',
        'Phim Bộ Tây Ban Nha': f'{ufn}/genre/phim-bo-tay-ban-nha',
        'Phim Bộ Thái Lan': f'{ufn}/genre/phim-bo-thai-lan',
        'Phim Bộ Thổ Nhĩ Kỳ': f'{ufn}/genre/phim-bo-tho-nhi-ky',
        'Phim Bộ Thụy Điển': f'{ufn}/genre/phim-bo-thuy-dien',
        'Phim Bộ Trung Quốc': f'{ufn}/genre/phim-bo-trung-quoc',
        'Phim Bộ Việt Nam': f'{ufn}/genre/phim-bo-viet-nam',
        'Phim Bộ Ý': f'{ufn}/genre/phim-bo-y'
    }
    for k in dulieu:
        addDir(k, ICON, k, None, None, None, 'thuvienhd_page', url = f'{dulieu[k]}/page/', p=1)
    endOfDirectory(HANDLE)
def tvhd_nhac():
    dulieu = {
        'Mới nhất':f'{ufn}/genre/music',
        'Chương Trình Xuân': f'{ufn}/genre/chuong_trinh-xuan',
        'Lossless': f'{ufn}/genre/lossless',
        'MV Châu Á': f'{ufn}/genre/wp-chau-a',
        'MV Quốc Tế': f'{ufn}/genre/wp-quoc-te',
        'MV Việt Nam': f'{ufn}/genre/wp-viet-nam'
    }
    for k in dulieu:
        addDir(k, ICON, k, None, None, None, 'thuvienhd_page', url = f'{dulieu[k]}/page/', p=1)
    endOfDirectory(HANDLE)
def fsmdb_full():
    addDir('Tìm phim', searchimg, 'Tìm phim', None, None, None, 'timkiem_fsmdb')
    T = {'Phân loại phim lẻ': 'fsmdb_phimle',
        'Phân loại phim bộ': 'fsmdb_phimbo'}
    dulieu = {
        'Trending': f'{tmdbAPI}/trending/all/day?api_key={apiKey}',
        'Popular Movies': f'{tmdbAPI}/movie/popular?api_key={apiKey}',
        'Popular TV Shows': f'{tmdbAPI}/tv/popular?api_key={apiKey}',
        'Airing Today TV Shows': f'{tmdbAPI}/tv/airing_today?api_key={apiKey}',
        'Netflix': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_networks=213',
        'Amazon': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_networks=1024',
        'Disney+': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_networks=2739',
        'Hulu': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_networks=453',
        'Apple TV+': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_networks=2552',
        'HBO': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_networks=49',
        'Paramount+': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_networks=4330',
        'Top Rated Movies': f'{tmdbAPI}/movie/top_rated?api_key={apiKey}',
        'Top Rated TV Shows': f'{tmdbAPI}/tv/top_rated?api_key={apiKey}',
        'Upcoming Movies': f'{tmdbAPI}/movie/upcoming?api_key={apiKey}',
        'Phim lẻ HQ': f'{tmdbAPI}/discover/movie?api_key={apiKey}&sort_by=popularity.desc&with_original_language=ko',
        'Phim bộ HQ': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_original_language=ko',
        'Phim lẻ TQ': f'{tmdbAPI}/discover/movie?api_key={apiKey}&sort_by=popularity.desc&with_original_language=zh',
        'Phim bộ TQ': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_original_language=zh',
        'Airing Today Anime': f'{tmdbAPI}/tv/airing_today?api_key={apiKey}&with_keywords=210024|222243&sort_by=primary_release_date.desc',
        'Ongoing Anime': f'{tmdbAPI}/tv/on_the_air?api_key={apiKey}&with_keywords=210024|222243&sort_by=primary_release_date.desc',
        'Anime': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_keywords=210024|222243',
        'Anime Movies': f'{tmdbAPI}/discover/movie?api_key={apiKey}&sort_by=popularity.desc&with_keywords=210024|222243'
        }
    for b in T:
        addDir(b, ICON, b, None, None, None, T[b])
    for k in dulieu:
        addDir(k, ICON, k, None, None, None, 'ds_fsmdb', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def fsmdb_phimle():
    u = f'{tmdbAPI}/genre/movie/list?api_key={apiKey}'
    r = getlink(u, u)
    dulieu = r.json()['genres']
    for k in dulieu:
        ten = k['name']
        url = f"{tmdbAPI}/discover/movie?api_key={apiKey}&sort_by=popularity.desc&with_genres={k['id']}"
        addDir(ten, ICON, ten, None, None, None, 'ds_fsmdb', url = url, p=1)
    endOfDirectory(HANDLE)
def fsmdb_phimbo():
    u = f'{tmdbAPI}/genre/tv/list?api_key={apiKey}'
    r = getlink(u, u)
    dulieu = r.json()['genres']
    for k in dulieu:
        ten = k['name']
        url = f"{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_genres={k['id']}"
        addDir(ten, ICON, ten, None, None, None, 'ds_fsmdb', url = url, p=1)
    endOfDirectory(HANDLE)
def ds_fsmdb(p, url):
    fsmdb(url, p)
    endOfDirectory(HANDLE)
def id_fsmdb(idp, u):
    if '/tv/' in u:
        url = f'{tmdbAPI}/tv/{idp}?api_key={apimdb}&language=en-US'
    else:
        url = f'{tmdbAPI}/movie/{idp}?api_key={apimdb}&language=en-US'
    r = getlink(url, url)
    timkiem(r.json()['title'])
def search_fsmdb():
    query = Dialog().input(u'Tìm: tên phim ...', type=INPUT_ALPHANUM)
    if query:
        search_history_save(query)
        timkiem_fsmdb(query)
    else:
        find_fsmdb()
def search():
    query = Dialog().input(u'Tìm: tên phim ...', type=INPUT_ALPHANUM)
    if query:
        search_history_save(query)
        timkiem(query)
    else:
        find()
def timvmf(paramslink):
    query = Dialog().input(u'Tìm: tên phim ...', type=INPUT_ALPHANUM)
    if query:
        search_query = quote_plus(query)
        url = f"{paramslink}{search_query}"
        listvmf_gcs(url)
    else:
        index_gcs()
def thuvienhd_page(p, url):
    trangtiep = f'{url}{p}'
    resp = getlink(trangtiep, trangtiep).text
    root = fromstring(resp).iterfind('.//div[@class="items"]//article')
    for k in root:
        name = domhtml(k, './/div[@class="data"]//a')
        img = domhtml(k, './/div[@class="poster"]//img', attribute='src')
        texto = domhtml(k, './/div[@class="texto"]', default=name)
        idp = k.get('id').split('-')[1] if k.get('id') else ''
        addDir(name, img, texto, None, None, None, 'thuvienhd_link', idk = idp, info = texto, ground = img)
    if 'nextpagination' in resp:
        trang = f'{p + 1}'
        addDir(f'Trang {trang}', nextimg, f'Trang {trang}', None, None, None, 'thuvienhd_page', url = url, p=trang)
    endOfDirectory(HANDLE)
def thuvienhd_link(url, mota, anh):
    t = f'{ufn}/download?id={url}'
    resp = getlink(t, t).text
    root = fromstring(resp).iterfind('.//tbody[@class="tbody outer"]//tr//td//a[@class="face-button"]')
    for k in root:
        link = k.get('href')
        if 'fshare.vn' in link:
            name = k.get('title')
            if 'folder' in link:
                addDir(name, anh, mota, None, link, None, 'index_fs', link = link, p=1, key = link)
            else:
                size = k.find('.//div[@class="face-secondary"]')
                size_text = convert_to_kb(''.join(size.itertext()).strip())
                addDir(name, anh, mota, size_text, link, None, 'play_fs', link = link, tenphim = name, key = link, is_folder=False)
    endOfDirectory(HANDLE)
def index_fs(paramslink, paramsp):
    folderfs = re.search(r'/(folder|file)/([A-Z0-9]+)', paramslink)[2]
    u = f'https://www.fshare.vn/api/v3/files/folder?linkcode={folderfs}&sort=type%2Cname&page={paramsp}&per-page=50'
    r = getlink(u, u)
    for k in r.json()['items']:
        tenm = k['name']
        if k['type'] == 1:
            linkfs = f'https://www.fshare.vn/file/{k["linkcode"]}'
            addDir(tenm, ICON, tenm, k['size'], linkfs, None, 'play_fs', link = linkfs, tenphim = tenm, key = linkfs, is_folder=False)
        else:
            linkfs = f'https://www.fshare.vn/folder/{k["linkcode"]}'
            addDir(tenm, ICON, tenm, None, linkfs, None, 'index_fs', link = linkfs, p=1, key = linkfs)
    if 'next' in r.json()['_links']:
        linkfds = f'https://www.fshare.vn/folder/{folderfs}'
        trang = f'{paramsp + 1}'
        addDir(f'Trang {trang}', nextimg, f'Trang {trang}', None, None, None, 'index_fs', link = linkfds, p=trang)
    endOfDirectory(HANDLE)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'caidat': caidat,
        'tangtockodi': writeAdvanced,
        'settingskodi': settingskodi,
        'check_myip': check_myip,
        'dubaothoitiet': dubaothoitiet,
        'thoitietmylocal': thoitietmylocal,
        'infoaccountfs' : infoaccountfs,
        'favouritefs': favouritefs,
        'weather': partial(weather, params.get('shortName'), params.get('idbm'), params.get('ten')),
        'add_key': partial(add_key, params.get('key')),
        'del_key': partial(del_key, params.get('key')),
        'speedtestcf': speedtestcf,
        'index_gcs': index_gcs,
        'tvhd_phimle': tvhd_phimle,
        'tvhd_phimbo': tvhd_phimbo,
        'tvhd_nhac': tvhd_nhac,
        'fsmdb_full': fsmdb_full,
        'fsmdb_phimle': fsmdb_phimle,
        'fsmdb_phimbo': fsmdb_phimbo,
        'ds_fsmdb': partial(ds_fsmdb, int(params.get('p', 1)), params.get('url')),
        'id_fsmdb': partial(id_fsmdb, params.get('id'), params.get('u')),
        'search_fsmdb': search_fsmdb,
        'search': search,
        'timvmf': partial(timvmf, params.get('link')),
        'timkiem': find,
        'timkiem_fsmdb': find_fsmdb,
        'tim_fs': partial(timkiem, params.get('key')),
        'tim_fsmdb': partial(timkiem_fsmdb, params.get('key')),
        'thuvienhd_page': partial(thuvienhd_page, int(params.get('p', 1)), params.get('url')),
        'thuvienhd_link': partial(thuvienhd_link, params.get('idk'), params.get('info'), params.get('ground')),
        'listvmf_gcs': partial(listvmf_gcs, params.get('link')),
        'listgg_gcs': partial(listgg_gcs, params.get('link')),
        'index_fs': partial(index_fs, params.get('link'), int(params.get('p', 1))),
        'play_fs': partial(play_fs, params.get('link')),
        'play_vnm': partial(play_vnm, params.get('link'), params.get('sub')),
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass
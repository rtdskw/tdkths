from xbmc import executebuiltin
from os.path import exists,join
from os import makedirs
from shutil import rmtree
from xbmcvfs import translatePath
thumb = translatePath('special://thumbnails/')
pack = translatePath('special://home/addons/packages')
thumbfolders = '0123456789abcdef'
def remove_folder(path):
	try:
		rmtree(path, ignore_errors=True, onerror=None)
	except:
		return False
if __name__ == '__main__':
	executebuiltin('UpdateAddonRepos()')
	if exists(pack):
		remove_folder(pack)
	if exists(thumb):
		remove_folder(thumb)
	if not exists(thumb):
		makedirs(thumb)
	videos = join(thumb,'Video','Bookmarks')
	for k in thumbfolders:
		foldname = join(thumb, k)
		if not exists(foldname):
			makedirs(foldname)
	if not exists(videos):
		makedirs(videos)
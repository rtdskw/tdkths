from urllib.parse import urlencode, parse_qsl, unquote
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from xbmc import executebuiltin
from time import sleep
import re, sys, xbmcgui, requests
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ICON = Addon().getAddonInfo('icon')
uthethao = 'https://raw.githubusercontent.com/t23-02/bongda/refs/heads/main/bongda.m3u'
UA = 'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/605.1.15 EdgA/133.0.0.0'
def getlink(url):
    r = requests.get(url, timeout=20, headers={'user-agent': UA,'referer': url.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def addDir(title, img, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
class m3u:
    @staticmethod
    def convert(m3u_file: str):
        m3u_json = []
        lines = m3u_file.split("\n")
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.startswith("#EXTINF"):
                channelInfo = {}
                try:
                    logoStartIndex = line.index('tvg-logo="') + 10
                    logoEndIndex = line.index('"', logoStartIndex)
                    logoUrl = line[logoStartIndex:logoEndIndex]
                except ValueError:
                    logoUrl = ""
                try:
                    groupTitleStartIndex = line.index('group-title="') + 13
                    groupTitleEndIndex = line.index('"', groupTitleStartIndex)
                    groupTitle = line[groupTitleStartIndex:groupTitleEndIndex]
                except ValueError:
                    groupTitle = ""
                titleStartIndex = line.rindex(",") + 1
                title = line[titleStartIndex:].strip() if "," in line else ""
                j = i + 1
                link = ""
                user_agent = ""
                referrer = ""
                while j < len(lines) and lines[j].startswith("#"):
                    if lines[j].startswith("#EXTVLCOPT:http-user-agent="):
                        user_agent = lines[j].split("=", 1)[1].strip()
                    elif lines[j].startswith("#EXTVLCOPT:http-referrer="):
                        referrer = lines[j].split("=", 1)[1].strip()
                    j += 1
                if j < len(lines):
                    link = lines[j].strip()
                channelInfo["tvg-logo"] = logoUrl
                channelInfo["group-title"] = groupTitle
                channelInfo["title"] = title
                channelInfo["link"] = link
                if user_agent:
                    channelInfo["user-agent"] = user_agent
                if referrer:
                    channelInfo["referrer"] = referrer
                m3u_json.append(channelInfo)
            i += 1
        return m3u_json
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        m3u_json = m3u.convert(getlink(uthethao).text)
        ld = []
        seen = set()
        for k in m3u_json:
            nhom = k['group-title']
            if nhom not in seen:
                seen.add(nhom)
                ld.append(nhom)
        for k in ld:
            addDir(k, ICON, 'group', nhom = k)
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'group':
        m3u_json = m3u.convert(getlink(uthethao).text)
        for k in m3u_json:
            if params['nhom'] == k['group-title']:
                logo = k.get('tvg-logo', ICON)
                name = k['title']
                link = k['link']
                user_agent = k.get('user-agent')
                referrer = k.get('referrer')
                addDir(name, logo, 'play', id = link, UA=user_agent, ref=referrer, is_folder=False)
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'play':
        play_item = xbmcgui.ListItem(offscreen=True)
        linkplay = re.sub(r'\s+', '%20', params['id'].strip(), flags=re.UNICODE)
        UA = params['UA']
        ref = params['ref']
        hdr = f"verifypeer=false&User-Agent={unquote(UA)}&Referer={ref}/"
        if 'm3u8' in linkplay:
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
            play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        else:
            linkplay = f"{linkplay}|{hdr}"
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])
from urllib.parse import urlencode, parse_qsl, unquote, urlparse
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from xbmc import executebuiltin
from time import sleep
import re, sys, requests, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/605.1.15 EdgA/133.0.0.0'
def addDir(title, logo, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': logo, 'thumb': logo, 'poster': logo, 'fanart': logo})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink():
    url = 'https://sport.xoilaczz.link/providers'
    r = requests.get(url, timeout=20, headers={'user-agent': UA,'referer': url.encode('utf-8')})
    r.encoding = 'utf-8'
    return r.json()['groups']
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        data = getlink()
        for k in getlink():
            if k.get('channels', ''):
                addDir(k['name'], ICON, 'list_thapcam', idk = k['id'])
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'list_thapcam':
        idp = params['idk']
        data = getlink()
        for k in data:
            if k.get('id', '') == idp:
                for a in k['channels']:
                    tentran = a['name']
                    idtran = a['id']
                    anhtran = a['image']['url']
                    if a.get('sources', ''):
                        org_metadata = a.get('org_metadata', {}).get('title', '')
                        m = re.search(r"(\d{2}:\d{2})", org_metadata)
                        thoigian = m.group(1) if m else ''
                        for b in a['sources']:
                            for c in b['contents']:
                                stream = sum(len(d.get('stream_links', [])) for d in c.get('streams', []))
                                tenf = f'{thoigian} {tentran}' if thoigian else tentran
                                if stream > 1:
                                    addDir(tenf, anhtran, 'detail_thapcam', idtran = idtran, idk = idp, idm = anhtran, idt = tentran)
                                else:
                                    for d in c['streams']:
                                        blv = d['name']
                                        for e in d['stream_links']:
                                            if e['type'] != 'webview':
                                                if e.get('request_headers'):
                                                    addDir(tenf, anhtran, 'play', link = e['url'], ref = e['request_headers'][0]['value'], is_folder=False)
                                                else:
                                                    addDir(tenf, anhtran, 'play', link = e['url'], is_folder=False)
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'detail_thapcam':
        idp = params['idk']
        idtran = params['idtran']
        anhtran = params['idm']
        tentran = params['idt']
        data = getlink()
        for k in data:
            if k.get('id', '') == idp:
                for a in k['channels']:
                    if a.get('sources', '') and a.get('id', '') == idtran:
                        for b in a['sources']:
                            for c in b['contents']:
                                for d in c['streams']:
                                    blv = d['name']
                                    for e in d['stream_links']:
                                        if e['type'] != 'webview':
                                            tenf = f'{tentran} | {blv} | {e["name"]}'
                                            if e.get('request_headers'):
                                                addDir(tenf, anhtran, 'play', link = e['url'], ref = e['request_headers'][0]['value'], is_folder=False)
                                            else:
                                                addDir(tenf, anhtran, 'play', link = e['url'], is_folder=False)
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'play':
        play_item = xbmcgui.ListItem(offscreen=True)
        hdr = f'verifypeer=false&User-Agent={unquote(UA)}'
        linkplay = re.sub(r'\s+', '%20', params['link'].strip(), flags=re.UNICODE)
        if params.get('ref'):
            hdr += f'&Referer={referer(params["ref"])}'
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])